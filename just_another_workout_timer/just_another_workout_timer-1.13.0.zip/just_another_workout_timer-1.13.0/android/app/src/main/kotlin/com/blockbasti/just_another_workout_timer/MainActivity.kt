package com.blockbasti.just_another_workout_timer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
